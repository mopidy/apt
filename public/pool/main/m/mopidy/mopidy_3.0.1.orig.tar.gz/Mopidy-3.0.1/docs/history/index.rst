.. _history:

*******
History
*******

These are the changelogs for historical releases of Mopidy.

For the latest releases, see :ref:`changelog`.

.. toctree::
    :maxdepth: 1

    changelog-2.x
    changelog-1.x
    changelog-0.x
