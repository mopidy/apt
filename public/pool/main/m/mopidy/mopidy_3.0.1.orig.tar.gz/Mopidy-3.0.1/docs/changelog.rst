.. _changelog:

*********
Changelog
*********

This changelog is used to track all major changes to Mopidy.

For older releases, see :ref:`history`.


v3.0.1 (2019-12-22)
===================

Bugfix release.

- Remove :mod:`mopidy.local` migration helper. (Fixes: :issue:`1861`, PR: `1862`)


v3.0.0 (2019-12-22)
===================

The long-awaited Mopidy 3.0 is finally here, just in time for the Mopidy
project's 10th anniversary on December 23rd!

Mopidy 3.0 is a backward-incompatible release in a pretty significant way:
Mopidy no longer runs on Python 2.

**Mopidy 3.0 requires Python 3.7 or newer.**

While extensions have been able to continue working without changes
throughout the 1.x and 2.x series of Mopidy, this time is different:

- All extensions must be updated to work on Python 3.7 and newer.

- Some extensions need to replace their use of a few long-deprecated APIs
  that we've removed. See below for details.

- Extension maintainers are also encouraged to update their project's setup to
  match our refreshed `extension cookiecutter`_.

In parallel with the development of Mopidy 3.0, we've coordinated with a few
extension maintainers and upgraded almost 20 of the most popular extensions.
These will all be published shortly after the release of Mopidy 3.0.

We've also built a new `extension registry`_, where you can quickly track what
extensions are ready for Python 3.

In other news, the `Mopidy-MPD`_ and `Mopidy-Local`_ extensions have grown up
and moved out to flourish as independent extension projects.
After the move, Mopidy-Local merged with Mopidy-Local-SQLite and
Mopidy-Local-Images, which are now both a part of the Mopidy-Local extension.

.. _extension cookiecutter: https://github.com/mopidy/cookiecutter-mopidy-ext
.. _extension registry: https://mopidy.com/ext/
.. _Mopidy-MPD: https://mopidy.com/ext/mpd/
.. _Mopidy-Local: https://mopidy.com/ext/local/


Dependencies
------------

- Python >= 3.7 is now required. Python 2.7 is no longer supported.

- GStreamer >= 1.14.0 is now required.

- Pykka >= 2.0.1 is now required.

- Tornado >= 4.4 is now required. The upper boundary (< 6) has been removed.

- We now use a number of constants and functions from ``GLib`` instead of their
  deprecated equivalents in ``GObject``. The exact version of PyGObject and
  GLib that makes these constants and functions available in the new location
  is not known, but is believed to have been released in 2015 or earlier.

Logging
-------

- The command line option ``mopidy --save-debug-log`` and the
  configuration :confval:`logging/debug_file` have been removed.
  To save a debug log for sharing, run ``mopidy -vvvv 2>&1 | tee mopidy.log``
  or equivalent. (Fixes: :issue:`1452`, PR: :issue:`1783`)

- Replaced the configurations :confval:`logging/console_format`
  and :confval:`logging/debug_format` with
  the single configuration :confval:`logging/format`.
  It defaults to the same format as the old debug format.
  (Fixes: :issue:`1452`, PR: :issue:`1783`)

- Added configuration :confval:`logging/verbosity` to be able to control
  logging verbosity from the configuration file,
  in addition to passing ``-q`` or ``-v`` on the command line.
  (Fixes: :issue:`1452`, PR: :issue:`1783`)

Core API
--------

- Removed properties, methods, and arguments that have been deprecated since
  1.0, released in 2015.
  Everything removed already has a replacement, that should be used instead.
  See below for a full list of removals and replacements.
  (Fixes: :issue:`1083`, :issue:`1461`, PR: :issue:`1768`, :issue:`1769`)

Root object
^^^^^^^^^^^

- Removed properties, use getter/setter instead:

  - :attr:`mopidy.core.Core.uri_schemes`
  - :attr:`mopidy.core.Core.version`

Library controller
^^^^^^^^^^^^^^^^^^

- Removed methods:

  - :meth:`mopidy.core.LibraryController.find_exact`:
    Use :meth:`~mopidy.core.LibraryController.search`
    with the keyword argument ``exact=True`` instead.

- Removed the ``uri`` argument to
  :meth:`mopidy.core.LibraryController.lookup`.
  Use the ``uris`` argument instead.

- Removed the support for passing the search query as keyword arguments to
  :meth:`mopidy.core.LibraryController.search`.
  Use the ``query`` argument instead.

- :meth:`mopidy.core.LibraryController.search` now returns an empty result
  if there is no ``query``. Previously, it returned the full music library.
  This does not work with online music services,
  and have thus been deprecated since 1.0.

Playback controller
^^^^^^^^^^^^^^^^^^^

- Removed properties, use getter/setter instead:

  - :attr:`mopidy.core.PlaybackController.current_tl_track`
  - :attr:`mopidy.core.PlaybackController.current_track`
  - :attr:`mopidy.core.PlaybackController.state`
  - :attr:`mopidy.core.PlaybackController.time_position`

- Moved to the mixer controller:

  - :meth:`mopidy.core.PlaybackController.get_mute`:
    Use :meth:`~mopidy.core.MixerController.get_mute`.

  - :meth:`mopidy.core.PlaybackController.get_volume`:
    Use :meth:`~mopidy.core.MixerController.get_volume`.

  - :meth:`mopidy.core.PlaybackController.set_mute`:
    Use :meth:`~mopidy.core.MixerController.set_mute`.

  - :meth:`mopidy.core.PlaybackController.set_volume`:
    Use :meth:`~mopidy.core.MixerController.set_volume`.

  - :attr:`mopidy.core.PlaybackController.mute`:
    Use :meth:`~mopidy.core.MixerController.get_mute`
    and :meth:`~mopidy.core.MixerController.set_mute`.

  - :attr:`mopidy.core.PlaybackController.volume`:
    Use :meth:`~mopidy.core.MixerController.get_volume`
    and :meth:`~mopidy.core.MixerController.set_volume`.

- Deprecated the ``tl_track`` argument to
  :meth:`mopidy.core.PlaybackController.play`, with the goal of removing it in
  the next major release. Use the ``tlid`` argument instead.
  (Fixes: #1773, PR: #1786, #1854)

Playlist controller
^^^^^^^^^^^^^^^^^^^

- Removed properties, use getter/setter instead:

  - :attr:`mopidy.core.PlaylistController.playlists`

- Removed methods:

  - :meth:`mopidy.core.PlaylistsController.filter`:
    Use :meth:`~mopidy.core.PlaylistsController.as_list` and filter yourself.

  - :meth:`mopidy.core.PlaylistsController.get_playlists`:
    Use :meth:`~mopidy.core.PlaylistsController.as_list` and
    :meth:`~mopidy.core.PlaylistsController.get_items`.

Tracklist controller
^^^^^^^^^^^^^^^^^^^^

- Removed properties, use getter/setter instead:

  - :attr:`mopidy.core.TracklistController.tl_tracks`
  - :attr:`mopidy.core.TracklistController.tracks`
  - :attr:`mopidy.core.TracklistController.length`
  - :attr:`mopidy.core.TracklistController.version`
  - :attr:`mopidy.core.TracklistController.consume`
  - :attr:`mopidy.core.TracklistController.random`
  - :attr:`mopidy.core.TracklistController.repeat`
  - :attr:`mopidy.core.TracklistController.single`

- Removed the ``uri`` argument to
  :meth:`mopidy.core.TracklistController.add`.
  Use the ``uris`` argument instead.

- Removed the support for passing filter criteria as keyword arguments to
  :meth:`mopidy.core.TracklistController.filter`.
  Use the ``criteria`` argument instead.

- Removed the support for passing filter criteria as keyword arguments to
  :meth:`mopidy.core.TracklistController.remove`.
  Use the ``criteria`` argument instead.

- Deprecated methods, with the goal of removing them in the next major release:
  (Fixes: #1773, PR: #1786, #1854)

  - :meth:`mopidy.core.TracklistController.eot_track`.
    Use :meth:`~mopidy.core.TracklistController.get_eot_tlid` instead.

  - :meth:`mopidy.core.TracklistController.next_track`.
    Use :meth:`~mopidy.core.TracklistController.get_next_tlid` instead.

  - :meth:`mopidy.core.TracklistController.previous_track`.
    Use :meth:`~mopidy.core.TracklistController.get_previous_tlid` instead.

- The ``tracks`` argument to :meth:`mopidy.core.TracklistController.add` has
  been deprecated since Mopidy 1.0. It is still deprecated, with the goal of
  removing it in the next major release. Use the ``uris`` argument instead.

Backend API
-----------

- Add :meth:`mopidy.backend.PlaybackProvider.is_live` which can be
  implemented by playback providers that wants to mark their URIs as
  live streams that should not be buffered. (PR: :issue:`1845`)

Models
------

- Remove ``.copy()`` method on all model classes.
  Use the ``.replace()`` method instead.
  (Fixes: :issue:`1464`, PR: :issue:`1774`)

- Remove :attr:`mopidy.models.Album.images`.
  Clients should use :meth:`mopidy.core.LibraryController.get_images` instead.
  Backends should implement :meth:`mopidy.backend.LibraryProvider.get_images`.
  (Fixes: :issue:`1464`, PR: :issue:`1774`)

Extension support
-----------------

- The following methods now return :class:`pathlib.Path` objects instead
  of strings:

  - :meth:`mopidy.ext.Extension.get_cache_dir`
  - :meth:`mopidy.ext.Extension.get_config_dir`
  - :meth:`mopidy.ext.Extension.get_data_dir`

  This makes it easier to support arbitrary encoding in file names.

- The command :command:`mopidy deps` no longer repeats the dependencies of
  Mopidy itself for every installed extension. This reduces the length of the
  command's output drastically. (PR: :issue:`1846`)

HTTP frontend
-------------

- Stop bundling Mopidy.js and serving it at ``/mopidy/mopidy.js`` and
  ``/mopidy/mopidy.min.js``. All Mopidy web clients must use Mopidy.js from npm
  or vendor their own copy of the library.
  (Fixes: :issue:`1083`, :issue:`1460`, PR: :issue:`1708`)

- Remove support for serving arbitrary files over HTTP through the use of
  :confval:`http/static_dir`, which has been deprecated since 1.0. (Fixes:
  :issue:`1463`, PR: :issue:`1706`)

- Add option :confval:`http/default_app` to redirect from web server root
  to a specific app instead of Mopidy's web app list. (PR: :issue:`1791`)

- Add cookie secret to Tornado web server, allowing Tornado request handlers to
  call ``get_secure_cookie()``, in an implementation of ``get_current_user()``.
  (PR: :issue:`1801`)

MPD frontend
------------

- The Mopidy-MPD frontend is no longer bundled with Mopidy, and has been moved
  to its own `Git repo <https://github.com/mopidy/mopidy-mpd>`__ and
  `PyPI project <https://pypi.org/project/Mopidy-MPD>`__.

Local backend
-------------

- The Mopidy-Local backend is no longer bundled with Mopidy, and has been moved
  to its own `Git repo <https://github.com/mopidy/mopidy-local>`__ and
  `PyPI project <https://pypi.org/project/Mopidy-Local>`__.
  (Fixes: :issue:`1003`)

- The :exc:`mopidy.exceptions.FindError` has been removed, as it was only
  used by Mopidy-Local. (PR: :issue:`1857`)

Audio
-----

- Remove the method :meth:`mopidy.audio.Audio.emit_end_of_stream`, which has
  been deprecated since 1.0. (Fixes: :issue:`1465`, PR: :issue:`1705`)

- Add ``live_stream`` option to :meth:`mopidy.audio.Audio.set_uri`
  that disables buffering, which reduces latency before playback starts,
  and discards data when paused. (PR: :issue:`1845`)

Internals
---------

- Format code with Black. (PR: :issue:`1834`)

- Port test assertions from ``unittest`` methods to pytest ``assert``
  statements. (PR: :issue:`1838`)

- Switch all internal path handling to use :mod:`pathlib`. (Fixes:
  :issue:`1744`, PR: :issue:`1814`)

- Remove :mod:`mopidy.compat` and all Python 2/3 compatibility code. (PR:
  :issue:`1833`, :issue:`1835`)

- Replace ``requirements.txt`` and ``setup.py`` with declarative config in
  ``setup.cfg``. (PR: :issue:`1839`)

- Refreshed and updated all of our end user-oriented documentation.
