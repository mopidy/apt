Installation
========================================================================

Debian/Ubuntu/Raspbian (jessie): Install the
``mopidy-internetarchive`` package from `apt.mopidy.com
<http://apt.mopidy.com/>`_::

  apt-get install mopidy-internetarchive

Otherwise, install the package from `PyPI
<https://pypi.python.org/pypi>`_::

  pip install Mopidy-Internetarchive
