Installation
========================================================================

Mopidy-InternetArchive can be installed using pip_ by running::

    pip install Mopidy-InternetArchive


.. _pip: https://pip.pypa.io/en/latest/
