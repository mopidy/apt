*******
Artists
*******

.. module:: spotify
    :noindex:

.. autoclass:: Artist

.. autoclass:: ArtistBrowser

.. autoclass:: ArtistBrowserType
    :no-inherited-members:
