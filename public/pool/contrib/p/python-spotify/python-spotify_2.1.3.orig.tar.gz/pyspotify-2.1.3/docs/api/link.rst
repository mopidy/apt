*****
Links
*****

.. module:: spotify
    :noindex:

.. autoclass:: Link

.. autoclass:: LinkType
    :no-inherited-members:
