********
Toplists
********

.. module:: spotify
    :noindex:

.. autoclass:: Toplist

.. autoclass:: ToplistRegion
    :no-inherited-members:

.. autoclass:: ToplistType
    :no-inherited-members:
