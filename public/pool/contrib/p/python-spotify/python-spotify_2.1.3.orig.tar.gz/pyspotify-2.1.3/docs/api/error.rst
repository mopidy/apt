**************
Error handling
**************

.. module:: spotify
    :noindex:

.. autoexception:: Error
    :no-undoc-members:
    :no-inherited-members:

.. autoclass:: ErrorType
    :no-inherited-members:

.. autoexception:: LibError
    :no-undoc-members:
    :no-inherited-members:

.. autoexception:: Timeout
    :no-undoc-members:
    :no-inherited-members:
