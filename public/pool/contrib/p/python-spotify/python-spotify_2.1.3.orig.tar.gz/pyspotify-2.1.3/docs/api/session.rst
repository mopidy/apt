********
Sessions
********

.. module:: spotify
    :noindex:

.. autoclass:: Session

.. autoclass:: SessionEvent
