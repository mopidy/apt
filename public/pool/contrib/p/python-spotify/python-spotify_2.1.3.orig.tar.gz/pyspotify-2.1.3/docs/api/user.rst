*****
Users
*****

.. module:: spotify
    :noindex:

.. autoclass:: User
