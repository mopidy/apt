******
Search
******

.. warning::

    The search API was broken at 2016-02-03 by a server-side change
    made by Spotify. The functionality was never restored.

    Please use the Spotify Web API to perform searches.

.. module:: spotify
    :noindex:

.. autoclass:: Search

.. autoclass:: SearchPlaylist

.. autoclass:: SearchType
    :no-inherited-members:
