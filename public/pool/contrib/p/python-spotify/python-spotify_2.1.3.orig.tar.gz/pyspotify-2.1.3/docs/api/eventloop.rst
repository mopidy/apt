**********
Event loop
**********

.. module:: spotify
    :noindex:

.. autoclass:: EventLoop
    :no-undoc-members:
    :no-inherited-members:
