*****
Inbox
*****

.. module:: spotify
    :noindex:

.. autoclass:: InboxPostResult
