******
Social
******

.. module:: spotify

.. autoclass:: spotify.social.Social

.. autoclass:: ScrobblingState
    :no-inherited-members:

.. autoclass:: SocialProvider
    :no-inherited-members:
