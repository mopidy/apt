******
Search
******

.. module:: spotify

.. autoclass:: Search

.. autoclass:: SearchPlaylist

.. autoclass:: SearchType
    :no-inherited-members:
