******
Player
******

.. module:: spotify

.. autoclass:: spotify.player.Player

.. autoclass:: spotify.player.PlayerState
