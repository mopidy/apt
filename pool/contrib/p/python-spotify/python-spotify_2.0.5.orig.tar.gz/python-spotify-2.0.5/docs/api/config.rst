*************
Configuration
*************

.. module:: spotify

.. autoclass:: Config
