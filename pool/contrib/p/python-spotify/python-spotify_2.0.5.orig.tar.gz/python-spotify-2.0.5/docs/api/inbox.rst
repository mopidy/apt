*****
Inbox
*****

.. module:: spotify

.. autoclass:: InboxPostResult
