************
Offline sync
************

.. module:: spotify

.. autoclass:: spotify.offline.Offline

.. autoclass:: OfflineSyncStatus
