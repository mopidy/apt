**********
Event loop
**********

.. module:: spotify

.. autoclass:: EventLoop
    :no-undoc-members:
    :no-inherited-members:
