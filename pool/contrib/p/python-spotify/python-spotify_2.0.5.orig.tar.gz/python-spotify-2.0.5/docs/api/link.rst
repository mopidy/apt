*****
Links
*****

.. module:: spotify

.. autoclass:: Link

.. autoclass:: LinkType
    :no-inherited-members:
