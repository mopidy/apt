********
Sessions
********

.. module:: spotify

.. autoclass:: Session

.. autoclass:: SessionEvent
