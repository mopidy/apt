******
Albums
******

.. module:: spotify

.. autoclass:: Album

.. autoclass:: AlbumBrowser

.. autoclass:: AlbumType
    :no-inherited-members:
