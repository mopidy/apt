*******
Artists
*******

.. module:: spotify

.. autoclass:: Artist

.. autoclass:: ArtistBrowser

.. autoclass:: ArtistBrowserType
    :no-inherited-members:
