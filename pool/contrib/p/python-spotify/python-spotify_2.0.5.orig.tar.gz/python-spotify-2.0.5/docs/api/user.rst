*****
Users
*****

.. module:: spotify

.. autoclass:: User
