=======
Proxies
=======

.. autoclass:: pykka.ActorProxy
    :members:

.. autoclass:: pykka.CallableProxy
    :members:

    .. automethod:: __call__

.. autofunction:: pykka.traversable
