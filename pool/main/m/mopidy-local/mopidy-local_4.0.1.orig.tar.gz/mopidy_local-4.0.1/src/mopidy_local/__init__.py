from __future__ import annotations

import pathlib
from importlib.metadata import version
from typing import TYPE_CHECKING, Any

from mopidy import config, ext

if TYPE_CHECKING:
    import cyclopts
    from mopidy.config import Config
    from mopidy.core import CoreProxy

__version__ = version("Mopidy-Local")


class Extension(ext.Extension):
    dist_name = "mopidy-local"
    ext_name = "local"
    version = __version__

    def get_default_config(self) -> str:
        return config.read(pathlib.Path(__file__).parent / "ext.conf")

    def get_config_schema(self) -> config.ConfigSchema:
        schema = super().get_config_schema()
        schema["library"] = config.Deprecated()
        schema["max_search_results"] = config.Integer(minimum=0)
        schema["media_dir"] = config.Path()
        schema["data_dir"] = config.Deprecated()
        schema["playlists_dir"] = config.Deprecated()
        schema["tag_cache_file"] = config.Deprecated()
        schema["scan_timeout"] = config.Integer(minimum=1000, maximum=1000 * 60 * 60)
        schema["scan_flush_threshold"] = config.Integer(minimum=0)
        schema["scan_follow_symlinks"] = config.Boolean()
        schema["included_file_extensions"] = config.List(optional=True)
        schema["excluded_file_extensions"] = config.List(optional=True)
        schema["directories"] = config.List()
        schema["timeout"] = config.Integer(optional=True, minimum=1)
        schema["use_artist_sortname"] = config.Boolean()
        schema["album_art_files"] = config.List(optional=True)
        return schema

    def setup(self, registry) -> None:
        from .actor import LocalBackend  # noqa: PLC0415

        registry.add("backend", LocalBackend)
        registry.add("http:app", {"name": self.ext_name, "factory": self.webapp})

    def get_command(self) -> cyclopts.App:
        from .commands import app  # noqa: PLC0415

        return app

    def webapp(self, config: Config, core: CoreProxy) -> list[Any]:  # noqa: ARG002
        from .web import ImageHandler, IndexHandler  # noqa: PLC0415

        image_dir = self.get_image_dir(config)
        return [
            (r"/(index.html)?", IndexHandler, {"root": image_dir}),
            (r"/(.+)", ImageHandler, {"path": image_dir}),
        ]

    # TODO: Add *paths to Extension.get_data_dir()?
    @classmethod
    def get_data_subdir(cls, config: Config, *paths: str) -> pathlib.Path:
        data_dir = cls.get_data_dir(config)
        dir_path = data_dir.joinpath(*paths)
        dir_path.mkdir(parents=True, exist_ok=True)
        return dir_path

    @classmethod
    def get_image_dir(cls, config: Config) -> pathlib.Path:
        return cls.get_data_subdir(config, "images")
