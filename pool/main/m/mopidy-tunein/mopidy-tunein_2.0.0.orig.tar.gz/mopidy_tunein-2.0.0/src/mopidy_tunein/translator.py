from __future__ import annotations

import logging
import re
from typing import TYPE_CHECKING, Final, Literal, get_args
from urllib import request
from urllib.parse import urlsplit, urlunsplit

from mopidy.models import Album, Artist, Image, Ref, Track
from mopidy.types import Uri

from mopidy_tunein.tunein import TuneIn

if TYPE_CHECKING:
    from mopidy.types import Query, SearchField

    from mopidy_tunein.tunein import TuneInItem

logger = logging.getLogger(__name__)

type Variant = Literal[
    "root",
    "category",
    "location",
    "section",
    "stations",
    "related",
    "shows",
    "episodes",
    "station",
]
"""The kinds of thing a tunein URI can point at."""

VARIANTS: Final = get_args(Variant.__value__)


def secure_image_uri(uri: str) -> Uri:
    """Give back a TuneIn image URI with the https scheme.

    The API answers with http, which a browser blocks as mixed content when
    it shows a Mopidy web client over https.
    """
    parts = urlsplit(uri)
    if (
        parts.scheme == "http"
        and parts.hostname
        and (parts.hostname == "tunein.com" or parts.hostname.endswith(".tunein.com"))
    ):
        return Uri(urlunsplit(parts._replace(scheme="https")))
    return Uri(uri)


def unparse_uri(variant: str, identifier: str) -> Uri:
    return Uri(f"tunein:{variant}:{identifier}")


def parse_uri(uri: str) -> tuple[Variant | None, str | None]:
    result = re.findall(r"^tunein:([a-z]+)(?::(\w+))?$", uri)
    if not result:
        return None, None
    variant, identifier = result[0]
    if variant not in VARIANTS:
        return None, None
    return variant, identifier or None


def unparse_page_uri(guide_id: str, offset: int) -> Uri:
    return unparse_uri("stations", f"{guide_id}_{offset}")


def parse_page(identifier: str) -> tuple[str, int]:
    guide_id, _, offset = identifier.partition("_")
    try:
        return guide_id, int(offset)
    except ValueError:
        return guide_id, 0


def station_to_ref(station: TuneInItem) -> Ref:
    if station["type"] != "audio":
        logger.debug(f"Expecting station but got {station['type']}")
    guide_id = station.get("guide_id", "??")
    uri = unparse_uri("station", guide_id)
    name = station.get("text", station["URL"])
    # TODO: Should the name include 'now playing' for all stations?
    if get_id_type(guide_id) == TuneIn.ID_TOPIC:
        name = f"{name} [{station.get('subtext', '??')}]"
    return Ref.track(uri=uri, name=name)


def station_to_track(station: TuneInItem) -> Track:
    ref = station_to_ref(station)
    return Track(
        uri=ref.uri,
        name=station.get("subtext", ref.name),
        album=Album(name=ref.name, uri=ref.uri),
        artists=frozenset([Artist(name=ref.name, uri=ref.uri)]),
    )


def station_to_image(station: TuneInItem | None) -> Image | None:
    if station is not None and "image" in station:
        return Image(uri=secure_image_uri(station["image"]))
    return None


def show_to_ref(show: TuneInItem) -> Ref:
    if show["item"] != "show":
        logger.debug(f"Expecting show but got {show['item']}")
    uri = unparse_uri("episodes", show.get("guide_id", "??"))
    name = show.get("text", show["URL"])
    return Ref.directory(uri=uri, name=name)


def category_to_ref(category: TuneInItem) -> Ref:
    uri = unparse_uri("category", category["key"])
    return Ref.directory(uri=uri, name=category["text"])


def section_to_ref(section: TuneInItem, identifier: str = "") -> Ref:
    if section.get("type", "link") == "audio":
        return station_to_ref(section)
    guide_id = section.get("guide_id", "??")
    if get_id_type(guide_id) == TuneIn.ID_REGION or identifier == "local":
        uri = unparse_uri("location", guide_id)
    else:
        uri = unparse_uri("section", guide_id)
    return Ref.directory(uri=uri, name=section["text"])


def get_id_type(guide_id: str) -> str:
    return {
        "p": TuneIn.ID_PROGRAM,
        "s": TuneIn.ID_STATION,
        "g": TuneIn.ID_GROUP,
        "t": TuneIn.ID_TOPIC,
        "c": TuneIn.ID_CATEGORY,
        "r": TuneIn.ID_REGION,
        "f": TuneIn.ID_PODCAST,
        "a": TuneIn.ID_AFFILIATE,
        "e": TuneIn.ID_STREAM,
    }.get(guide_id[0], TuneIn.ID_UNKNOWN)


def mopidy_to_tunein_query(mopidy_query: Query[SearchField]) -> str:
    tunein_query = [
        str(value)
        for field, values in mopidy_query.items()
        if field == "any"
        for value in values
    ]
    query = " ".join(tunein_query)
    return request.pathname2url(query)
