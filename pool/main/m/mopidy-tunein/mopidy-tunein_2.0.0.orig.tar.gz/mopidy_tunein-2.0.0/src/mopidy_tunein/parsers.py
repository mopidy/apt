import configparser
import io
import urllib.parse
from collections.abc import Generator
from xml.etree import ElementTree as ET


def parse_playlist(data: bytes) -> list[str]:
    handlers = {
        detect_extm3u_header: parse_extm3u,
        detect_pls_header: parse_pls,
        detect_asx_reference_header: parse_asx_reference,
        detect_asx_header: parse_asx,
        detect_xspf_header: parse_xspf,
    }
    for detector, parser in handlers.items():
        if detector(data):
            return list(parser(data))
    return list(parse_urilist(data))  # Fallback


def detect_extm3u_header(data: bytes) -> bool:
    return data[0:7].upper() == b"#EXTM3U"


def detect_pls_header(data: bytes) -> bool:
    return data[0:10].lower() == b"[playlist]"


def detect_asx_reference_header(data: bytes) -> bool:
    return data[0:11].lower() == b"[reference]"


def detect_xspf_header(data: bytes) -> bool:
    data = data[0:150]
    if b"xspf" not in data.lower():
        return False

    try:
        fh = io.BytesIO(data)
        for _event, element in ET.iterparse(fh, events=["start"]):
            return element.tag.lower() == "{http://xspf.org/ns/0/}playlist"
    except ET.ParseError:
        pass
    return False


def detect_asx_header(data: bytes) -> bool:
    data = data[0:50]
    if b"asx" not in data.lower():
        return False

    try:
        fh = io.BytesIO(data)
        for _event, element in ET.iterparse(fh, events=["start"]):
            return element.tag.lower() == "asx"
    except ET.ParseError:
        pass
    return False


def parse_extm3u(data: bytes) -> Generator[str]:
    # TODO: convert non URIs to file URIs.
    found_header = False
    for line in data.splitlines():
        if found_header or line.startswith(b"#EXTM3U"):
            found_header = True
        else:
            continue

        if not line.strip() or line.startswith(b"#"):
            continue

        try:
            line = line.decode()
        except UnicodeDecodeError:
            continue

        yield line.strip()


def parse_pls(data: bytes) -> Generator[str]:
    # TODO: convert non URIs to file URIs.
    try:
        cp = configparser.RawConfigParser(strict=False)
        cp.read_string(data.decode())
    except configparser.Error:
        return

    for section in cp.sections():
        if section.lower() != "playlist":
            continue
        # Malformed playlists often declare a NumberOfEntries that does not
        # match the File keys they have. Use the File keys instead.
        entries = (
            (int(option[4:]), cp.get(section, option))
            for option in cp.options(section)
            if option.startswith("file") and option[4:].isdigit()
        )
        for _index, entry in sorted(entries):
            if uri := entry.strip("\"'"):
                yield uri


def parse_asx_reference(data: bytes) -> Generator[str]:
    try:
        cp = configparser.RawConfigParser(strict=False)
        cp.read_string(data.decode())
    except configparser.Error:
        return

    for section in cp.sections():
        if section.lower() != "reference":
            continue
        references = (
            (int(option[3:]), cp.get(section, option))
            for option in cp.options(section)
            if option.startswith("ref") and option[3:].isdigit()
        )
        for _index, reference in sorted(references):
            if uri := reference.strip("\"'"):
                yield uri


def parse_xspf(data: bytes) -> Generator[str]:
    element = None
    try:
        # Last element will be root.
        for _event, element in ET.iterparse(io.BytesIO(data)):
            element.tag = element.tag.lower()  # normalize
    except ET.ParseError:
        return
    if element is None:
        return

    ns = "http://xspf.org/ns/0/"
    path = f"{{{ns}}}tracklist/{{{ns}}}track"
    for track in element.iterfind(str(path)):
        if result := track.findtext(f"{{{ns}}}location"):
            yield result


def parse_asx(data: bytes) -> Generator[str]:
    element = None
    try:
        # Last element will be root.
        for _event, element in ET.iterparse(io.BytesIO(data)):
            element.tag = element.tag.lower()  # normalize
    except ET.ParseError:
        return
    if element is None:
        return

    for ref in element.findall("entry/ref[@href]"):
        yield ref.get("href", "").strip()

    for entry in element.findall("entry[@href]"):
        yield entry.get("href", "").strip()


def parse_urilist(data: bytes) -> Generator[str]:
    for line in data.splitlines():
        if not line.strip() or line.startswith(b"#"):
            continue

        try:
            line = line.decode()
        except UnicodeDecodeError:
            continue

        try:
            result = urllib.parse.urlparse(line)
        except ValueError:
            continue
        if result.scheme == "":
            continue

        yield line.strip()
