"""Implementation of org.mpris.MediaPlayer2 interface.

https://specifications.freedesktop.org/mpris/latest/Media_Player.html
"""

# ruff: noqa: N802

import logging

from mopidy_mpris.interface import Interface

logger = logging.getLogger(__name__)


class Root(Interface):
    """
    <node>
      <interface name="org.mpris.MediaPlayer2">
        <method name="Raise"/>
        <method name="Quit"/>
        <property name="CanQuit" type="b" access="read"/>
        <property name="CanRaise" type="b" access="read"/>
        <property name="Fullscreen" type="b" access="readwrite"/>
        <property name="CanSetFullscreen" type="b" access="read"/>
        <property name="HasTrackList" type="b" access="read"/>
        <property name="Identity" type="s" access="read"/>
        <property name="DesktopEntry" type="s" access="read"/>
        <property name="SupportedUriSchemes" type="as" access="read"/>
        <property name="SupportedMimeTypes" type="as" access="read"/>
      </interface>
    </node>
    """

    INTERFACE = "org.mpris.MediaPlayer2"

    def Raise(self) -> None:
        logger.debug("%s.Raise called", self.INTERFACE)
        # Do nothing, as we do not have a GUI

    def Quit(self) -> None:
        logger.debug("%s.Quit called", self.INTERFACE)
        # Do nothing, as we do not allow MPRIS clients to shut down Mopidy

    CanQuit = False

    @property
    def Fullscreen(self) -> bool:
        self.log_trace("Getting %s.Fullscreen", self.INTERFACE)
        return False

    @Fullscreen.setter
    def Fullscreen(self, value: bool) -> None:
        logger.debug("Setting %s.Fullscreen to %s", self.INTERFACE, value)

    CanSetFullscreen = False
    CanRaise = False
    HasTrackList = False  # NOTE Change if adding optional track list support
    Identity = "Mopidy"

    @property
    def DesktopEntry(self) -> str:
        self.log_trace("Getting %s.DesktopEntry", self.INTERFACE)
        # This property is optional to expose. If we set this to "mopidy", the
        # basename of "mopidy.desktop", some MPRIS clients will start a new
        # Mopidy instance in a terminal window if one clicks outside the
        # buttons of the UI. This is probably never what the user wants.
        return ""

    @property
    def SupportedUriSchemes(self) -> list[str]:
        self.log_trace("Getting %s.SupportedUriSchemes", self.INTERFACE)
        return [str(uri_scheme) for uri_scheme in self.core.get_uri_schemes().get()]

    @property
    def SupportedMimeTypes(self) -> list[str]:
        # NOTE Return MIME types supported by local backend if support for
        # reporting supported MIME types is added.
        self.log_trace("Getting %s.SupportedMimeTypes", self.INTERFACE)
        return [
            "audio/mpeg",
            "audio/x-ms-wma",
            "audio/x-ms-asf",
            "audio/x-flac",
            "audio/flac",
            "audio/l16;channels=2;rate=44100",
            "audio/l16;rate=44100;channels=2",
        ]
