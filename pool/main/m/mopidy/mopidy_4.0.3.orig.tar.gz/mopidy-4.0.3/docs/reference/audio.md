# Audio API

The audio API is the interface we have built around GStreamer to support our
specific use cases. Most backends should be able to get by with simply setting
the URI of the resource they want to play, for these cases the default playback
provider should be used.

For more advanced cases such as when the raw audio data is delivered outside of
GStreamer or the backend needs to add metadata to the currently playing
resource, developers should sub-class the base playback provider and implement
the extra behaviour that is needed through the following API:

::: mopidy.audio
    options:
      heading_level: 2

::: mopidy.audio.scan
    options:
      heading_level: 2

::: mopidy.audio.tags
    options:
      heading_level: 2
