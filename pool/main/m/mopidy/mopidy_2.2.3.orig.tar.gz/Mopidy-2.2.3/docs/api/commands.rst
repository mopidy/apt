.. _commands-api:

***************************************
:mod:`mopidy.commands` --- Commands API
***************************************

.. automodule:: mopidy.commands
    :synopsis: Commands API for Mopidy CLI.
    :members:
