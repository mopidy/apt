.. _sponsors:

********
Sponsors
********

The Mopidy project would like to thank the following sponsors for supporting
the project.


Discourse
=========

`Discourse <https://www.discourse.org/>`_ sponsors Mopidy with free hosting of
our discussion forum at https://discourse.mopidy.com.
