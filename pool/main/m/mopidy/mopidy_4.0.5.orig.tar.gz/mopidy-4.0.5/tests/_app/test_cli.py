from pathlib import Path

from cyclopts import Token

from mopidy._app import cli


def test_config_paths_converter() -> None:
    # Single path
    assert cli.config_paths_converter(
        list[Path],
        [Token(value="~/.config/mopidy/mopidy.conf")],
    ) == [
        Path("~/.config/mopidy/mopidy.conf").expanduser(),
    ]

    # Multiple paths separated by colon
    assert cli.config_paths_converter(
        list[Path],
        [Token(value="~/.config/mopidy/mopidy.conf:/etc/mopidy/mopidy.conf")],
    ) == [
        Path("~/.config/mopidy/mopidy.conf").expanduser(),
        Path("/etc/mopidy/mopidy.conf"),
    ]

    # Multiple paths via repeated --config parameters
    assert cli.config_paths_converter(
        list[Path],
        [
            Token(value="~/.config/mopidy/mopidy.conf"),
            Token(value="/etc/mopidy/mopidy.conf"),
        ],
    ) == [
        Path("~/.config/mopidy/mopidy.conf").expanduser(),
        Path("/etc/mopidy/mopidy.conf"),
    ]


def test_config_overrides_converter() -> None:
    assert cli.config_overrides_converter(
        dict[str, dict[str, str]],
        [
            Token(value="section1/keyA=value1A"),
            Token(value="section2/keyA=value2A"),
            Token(value="section1/keyB=value1B"),
        ],
    ) == [
        {
            "section1": {
                "keyA": "value1A",
                "keyB": "value1B",
            },
            "section2": {
                "keyA": "value2A",
            },
        }
    ]


def test_config_overrides_multiple_values() -> None:
    args = [
        "run",
        "-o",
        "http/port=1111",
        "-o",
        "http/hostname=127.0.0.1",
    ]

    _, bound, _ = cli.app.meta.parse_args(args)

    assert bound.arguments["config_overrides"][0] == {
        "http": {
            "port": "1111",
            "hostname": "127.0.0.1",
        }
    }


def test_verbosity_from_repeated_parameters() -> None:
    # Not given, so the parameter is absent from the bound arguments
    _, bound, _ = cli.app.meta.parse_args(["run"])
    assert sum(bound.arguments.get("verbosity") or []) == 0

    # Given once
    _, bound, _ = cli.app.meta.parse_args(["run", "-v"])
    assert sum(bound.arguments["verbosity"] or []) == 1

    # Given twice
    _, bound, _ = cli.app.meta.parse_args(["run", "--verbose", "--verbose"])
    assert sum(bound.arguments["verbosity"] or []) == 2
