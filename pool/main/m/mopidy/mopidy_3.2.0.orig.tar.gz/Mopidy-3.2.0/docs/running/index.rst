.. _running:

*******
Running
*******

There are two primary ways to run Mopidy. What way is best depends upon your
goals and preferences:

.. toctree::

    terminal
    service
