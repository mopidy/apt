.. _zeroconf-api:

***************************************
:mod:`mopidy.zeroconf` --- Zeroconf API
***************************************

.. module:: mopidy.zeroconf
    :synopsis: Helper for publishing of services on Zeroconf

.. autoclass:: Zeroconf
    :members:
