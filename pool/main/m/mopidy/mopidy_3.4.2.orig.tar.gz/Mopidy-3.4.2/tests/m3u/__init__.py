def generate_song(i):
    return f"dummy:track:song{i}"
