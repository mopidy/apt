import importlib.util
import sys
from importlib.metadata import Distribution, DistributionFinder
from pathlib import Path


class UninstalledDistributionFinder(DistributionFinder):
    """Find mopidy's metadata despite it not being installed."""

    @staticmethod
    def find_spec(fullname, path=None, target=None):
        return None

    @staticmethod
    def find_module(fullname, path):
        return None

    @staticmethod
    def invalidate_caches():
        pass

    @staticmethod
    def find_distributions(context=DistributionFinder.Context()):
        if context.name == "Mopidy":
            return [Distribution.at(Path(__file__).parent / "mopidy")]
        else:
            return []


sys.meta_path.append(UninstalledDistributionFinder)


# polyfactory is in unstable only. It has been blocked from testing since
# March 2026, and it blocks mopidy from testing too. Do not collect the tests
# that need it, so that mopidy does not need it as a build dependency. Collect
# them again when polyfactory is in testing.
if importlib.util.find_spec("polyfactory") is None:
    collect_ignore = [
        "tests/core/test_listener.py",
        "tests/core/test_playlists.py",
        "tests/core/test_tracklist.py",
        "tests/models/test_album.py",
        "tests/models/test_artist.py",
        "tests/models/test_image.py",
        "tests/models/test_playlist.py",
        "tests/models/test_replace.py",
        "tests/models/test_search_result.py",
        "tests/models/test_tl_track.py",
        "tests/models/test_track.py",
    ]
