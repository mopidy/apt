from __future__ import annotations

import asyncio
import logging
import secrets
import socket
import textwrap
import threading
from typing import TYPE_CHECKING, ClassVar, cast, override

import pykka
import tornado.httpserver
import tornado.ioloop
import tornado.netutil
import tornado.web
import tornado.websocket
from pydantic import TypeAdapter

from mopidy import exceptions, zeroconf
from mopidy.core import CoreEvent, CoreEventData, CoreListener

from . import Extension, handlers, network
from .types import HttpConfig, RequestRule

if TYPE_CHECKING:
    from mopidy.config import Config
    from mopidy.core import CoreProxy

    from .types import HttpApp, HttpStatic


logger = logging.getLogger(__name__)


CoreEventTypeAdapter = TypeAdapter(dict[str, CoreEventData])


class HttpFrontend(pykka.ThreadingActor, CoreListener):
    apps: ClassVar[list[HttpApp]] = []
    statics: ClassVar[list[HttpStatic]] = []

    @override
    def __init__(self, config: Config, core: CoreProxy) -> None:
        super().__init__()

        http_config = cast(HttpConfig, config[Extension.ext_name])
        self.hostname = network.format_hostname(http_config["hostname"])
        self.port = http_config["port"]
        tornado_hostname = http_config["hostname"]
        if tornado_hostname == "::":
            tornado_hostname = None

        try:
            logger.debug("Starting HTTP server")
            sockets = tornado.netutil.bind_sockets(self.port, tornado_hostname)
            self.server = HttpServer(
                config=config,
                core=core,
                sockets=sockets,
                apps=self.apps,
                statics=self.statics,
            )
        except OSError as exc:
            msg = "HTTP server startup failed."
            raise exceptions.FrontendError(msg) from exc

        self.zeroconf_name = http_config["zeroconf"]
        self.zeroconf_http = None
        self.zeroconf_mopidy_http = None

    @override
    def on_start(self) -> None:
        logger.info("HTTP server running at [%s]:%s", self.hostname, self.port)
        self.server.start()

        if self.zeroconf_name:
            self.zeroconf_http = zeroconf.Zeroconf(
                name=self.zeroconf_name,
                stype="_http._tcp",
                port=self.port,
            )
            self.zeroconf_mopidy_http = zeroconf.Zeroconf(
                name=self.zeroconf_name,
                stype="_mopidy-http._tcp",
                port=self.port,
            )
            self.zeroconf_http.publish()
            self.zeroconf_mopidy_http.publish()

    @override
    def on_stop(self) -> None:
        if self.zeroconf_http:
            self.zeroconf_http.unpublish()
        if self.zeroconf_mopidy_http:
            self.zeroconf_mopidy_http.unpublish()

        self.server.stop()

    @override
    def on_event(
        self,
        event: CoreEvent,
        **data: CoreEventData,
    ) -> None:
        if not self.server.io_loop:
            return
        on_event(event, self.server.io_loop, **data)


def on_event(
    name: CoreEvent,
    io_loop: tornado.ioloop.IOLoop,
    **data: CoreEventData,
) -> None:
    event = data
    event["event"] = name
    message = CoreEventTypeAdapter.dump_json(event)
    handlers.WebSocketHandler.broadcast(message, io_loop)


class HttpServer(threading.Thread):
    name = "HttpServer"

    def __init__(
        self,
        config: Config,
        core: CoreProxy,
        sockets: list[socket.socket],
        apps: list[HttpApp],
        statics: list[HttpStatic],
    ) -> None:
        super().__init__()

        self.config = config
        self.core = core
        self.sockets = sockets
        self.apps = apps
        self.statics = statics

        self.app = None
        self.server = None
        self.io_loop = None

    def run(self) -> None:
        # Since we start Tornado in a another thread than the main thread,
        # we must explicitly create an asyncio loop for the current thread.
        asyncio.set_event_loop(asyncio.new_event_loop())

        self.app = tornado.web.Application(
            self._get_request_handlers(),  # pyright: ignore[reportArgumentType]
            cookie_secret=self._get_cookie_secret(),
        )
        self.server = tornado.httpserver.HTTPServer(self.app)
        self.server.add_sockets(self.sockets)

        self.io_loop = tornado.ioloop.IOLoop.current()
        self.io_loop.start()

        logger.debug("Stopped HTTP server")

    def stop(self) -> None:
        logger.debug("Stopping HTTP server")
        assert self.io_loop
        self.io_loop.add_callback(self.io_loop.stop)

    def _get_request_handlers(self) -> list[RequestRule]:
        request_handlers = []
        request_handlers.extend(self._get_app_request_handlers())
        request_handlers.extend(self._get_static_request_handlers())
        request_handlers.extend(self._get_default_request_handlers())

        logger.debug(
            "HTTP routes from extensions:\n%s",
            textwrap.indent(
                text="\n".join(
                    f"{path!r}: {handler!r}" for (path, handler, *_) in request_handlers
                ),
                prefix="    ",
            ),
        )

        return request_handlers

    def _get_app_request_handlers(self) -> list[RequestRule]:
        result = list[RequestRule]()
        for app in self.apps:
            try:
                request_handlers = app["factory"](self.config, self.core)
            except Exception:
                logger.exception("Loading %s failed.", app["name"])
                continue

            result.append((f"/{app['name']}", handlers.AddSlashHandler))
            for rule in request_handlers:
                prefixed_rule = (f"/{app['name']}{rule[0]}", *rule[1:])
                result.append(cast("RequestRule", prefixed_rule))
            logger.debug("Loaded HTTP extension: %s", app["name"])
        return result

    def _get_static_request_handlers(self) -> list[RequestRule]:
        result = list[RequestRule]()
        for static in self.statics:
            result.append((f"/{static['name']}", handlers.AddSlashHandler))
            result.append(
                (
                    f"/{static['name']}/(.*)",
                    handlers.StaticFileHandler,
                    {"path": static["path"], "default_filename": "index.html"},
                ),
            )
            logger.debug("Loaded static HTTP extension: %s", static["name"])
        return result

    def _get_default_request_handlers(self) -> list[RequestRule]:
        sites = [app["name"] for app in self.apps + self.statics]

        http_config = cast(HttpConfig, self.config[Extension.ext_name])
        default_app = http_config["default_app"]
        if default_app not in sites:
            logger.warning(f"HTTP server's default app {default_app!r} not found")
            default_app = "mopidy"
        logger.debug(f"Default webclient is {default_app}")

        return [
            (
                r"/",
                tornado.web.RedirectHandler,
                {"url": f"/{default_app}/", "permanent": False},
            ),
        ]

    def _get_cookie_secret(self) -> str:
        file_path = Extension.get_data_dir(self.config) / "cookie_secret"
        if not file_path.is_file():
            cookie_secret = secrets.token_hex(32)
            file_path.write_text(cookie_secret)
        else:
            cookie_secret = file_path.read_text().strip()
            if not cookie_secret:
                logger.error(
                    f"HTTP server could not find cookie secret in {file_path}",
                )
        return cookie_secret
