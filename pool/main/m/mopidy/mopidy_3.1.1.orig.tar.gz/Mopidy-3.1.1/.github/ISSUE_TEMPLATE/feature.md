---
name: Feature request
about: Suggest an idea for this project.
title: ''
labels: ''
assignees: ''

---

Mopidy's GitHub Issues are reserved for well-defined feature requests. If this is a more general idea or question, please post on the [forum](https://discourse.mopidy.com) first.
