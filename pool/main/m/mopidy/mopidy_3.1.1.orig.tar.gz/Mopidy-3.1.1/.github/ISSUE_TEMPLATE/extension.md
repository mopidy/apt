---
name: Extension request
about: Share your idea for a new Mopidy extension.
title: ''
labels: C-extension-request
assignees: ''

---

Please explain your idea and provide any information on how the extension might be implemented. See [here](https://discourse.mopidy.com/t/supporting-new-streaming-services-and-other-music-sources/22) for more information.

Note: these issues are closed as they cannot be fixed in Mopidy itself. However, they will be added to our [Extension wishlist](https://github.com/mopidy/mopidy/issues?utf8=%E2%9C%93&q=label%3AC-extension-request+) label for potential authors/collaborators to find and discuss.
