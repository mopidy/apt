Please use https://discourse.mopidy.com/ for support questions.

GitHub Issues should only be used for confirmed problems with Mopidy and well-defined feature requests.
