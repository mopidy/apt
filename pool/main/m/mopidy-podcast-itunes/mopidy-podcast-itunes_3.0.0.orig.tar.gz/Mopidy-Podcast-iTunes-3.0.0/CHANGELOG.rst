v3.0.0 (2019-12-25)
===================

- Depend on final release of Mopidy 3.0.0.


v3.0.0a1 (2019-12-06)
=====================

- Require Python >= 3.7.

- Require Mopidy >= 3.0.0a5.

- Require Pykka >= 2.0.1.

- Update project setup.


v2.0.0 (2016-03-23)
===================

- Converted from Mopidy-Podcast directory extension to regular Mopidy
  backend extension.  No longer uses Mopidy-Podcast directory API.

- Add workaround for apparent changes in iTunes search API regarding
  the ``explicit`` parameter.

- Add HTTP connection retries configuration.

- Upgrade dependencies to Mopidy v1.1 and Mopidy-Podcast v2.0.


v1.0.0 (2014-05-24)
===================

- Upgrade to Mopidy-Podcast v1.0.0 directory API.

- Add support for undocumented search attributes.

- Support custom formatting of search/browse results.


v0.2.0 (2014-04-11)
===================

- Upgrade to Mopidy-Podcast v0.4.0 directory API.

- Separate charts directory if subgenres are present.

- Support for ``genreTerm`` search attribute.


v0.1.0 (2014-03-14)
===================

- Initial release.
