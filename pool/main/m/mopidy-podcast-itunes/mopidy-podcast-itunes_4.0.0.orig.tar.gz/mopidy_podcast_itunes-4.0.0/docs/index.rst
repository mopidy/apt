:tocdepth: 3

*********************
Mopidy-Podcast-iTunes
*********************

Mopidy-Podcast-iTunes is a Mopidy_ extension for searching and
browsing podcasts on `Apple Podcasts`_, using the `iTunes Search
API`_.

.. note::

   The iTunes Search API is limited to approximately 20 calls per
   minute (subject to change).  Mopidy-Podcast-iTunes uses in-memory
   caching extensively, so you should not be affected by this limit
   with normal, interactive usage.


*************
Configuration
*************

This extension provides a number of configuration values that can be
tweaked.  However, the :ref:`default configuration <defconf>` should
contain everything to get you up and running, and will usually require
only a few modifications, if any, to match personal preferences.


.. _confvals:

Configuration Values
====================

.. confval:: enabled

   Whether this extension should be enabled or not.

.. confval:: base_url

   The iTunes Search API base URL.

.. confval:: country

   The two-letter country code for the store you want to search.

.. confval:: explicit

   Whether you want to include explicit content in your search results.

.. confval:: charts_limit

   The maximum number of podcast charts entries to retrieve when browsing.

.. confval:: search_limit

   The maximum number of search results to retrieve.

.. confval:: timeout

   The HTTP request timeout in seconds when using the Search API.

.. confval:: retries

   The maximum number of HTTP connection retries when using the Search API.


.. _defconf:

Default Configuration
=====================

For reference, this is the default configuration shipped with
Mopidy-Podcast-iTunes release |release|:

.. literalinclude:: ../src/mopidy_podcast_itunes/ext.conf
   :language: ini

.. _Mopidy: https://www.mopidy.com/
.. _Apple Podcasts: https://podcasts.apple.com/
.. _iTunes Search API: https://performance-partners.apple.com/search-api
