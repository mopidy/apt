4.0.0 (2026-05-25)
===================

- Require Mopidy >= 4.0.0.

- Remove deprecated configuration entries.

- Update build environment.


v3.1.3 (2026-04-16)
===================

- Improve error handling.


v3.1.2 (2026-04-11)
===================

- Update and re-enable browsing tests.

- Minor documentation improvements.


v3.1.1 (2026-04-10)
===================

- Minor documentation improvements.


v3.1.0 (2026-04-08)
===================

- Add support for Python <= 3.14.

- Rename root directory to "Apple Podcasts".

- Re-enable podcast charts browsing by switching to currently
  supported APIs.

- Move documentation to
  `<https://mopidy-podcast-itunes.readthedocs.io>`_.

- Update unit tests fur use with current pytest versions.

- Modernize build environment and packages structure.

- Update CI environment.


v3.0.1 (2022-04-03)
===================

- Officially support Python 3.9 and 3.10.


v3.0.0 (2019-12-25)
===================

- Depend on final release of Mopidy 3.0.0.


v3.0.0a1 (2019-12-06)
=====================

- Require Python >= 3.7.

- Require Mopidy >= 3.0.0a5.

- Require Pykka >= 2.0.1.

- Update project setup.


v2.0.0 (2016-03-23)
===================

- Converted from Mopidy-Podcast directory extension to regular Mopidy
  backend extension.  No longer uses Mopidy-Podcast directory API.

- Add workaround for apparent changes in iTunes search API regarding
  the ``explicit`` parameter.

- Add HTTP connection retries configuration.

- Upgrade dependencies to Mopidy v1.1 and Mopidy-Podcast v2.0.


v1.0.0 (2014-05-24)
===================

- Upgrade to Mopidy-Podcast v1.0.0 directory API.

- Add support for undocumented search attributes.

- Support custom formatting of search/browse results.


v0.2.0 (2014-04-11)
===================

- Upgrade to Mopidy-Podcast v0.4.0 directory API.

- Separate charts directory if subgenres are present.

- Support for ``genreTerm`` search attribute.


v0.1.0 (2014-03-14)
===================

- Initial release.
